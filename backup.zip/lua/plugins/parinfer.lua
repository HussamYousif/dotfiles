return {
  "gpanders/nvim-parinfer",
  ft = "clojure",
}
